<?php $__env->startSection('content'); ?>

<div class="login-box">
    <div class="login-logo">
        <a href="#">soccertipstar</a>
    </div>
    <!-- /.site-logo -->
    <div class="login-box-body">
        <p class="login-box-msg">Forgot Password?</p>

        <?php if(session('status')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(session('status')); ?>

            </div>
        <?php endif; ?>

        <form method="POST" action="<?php echo e(route('password.email')); ?>">
            <?php echo csrf_field(); ?>
            <div class="form-group has-feedback">
              <input    id="email" 
                        type="email" 
                        class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" 
                        name="email" 
                        value="<?php echo e(old('email')); ?>" 
                        required 
                        autocomplete="email" 
                        autofocus 
                        placeholder="Email">

                <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                    <span class="invalid-feedback" role="alert">
                        <strong><?php echo e($message); ?></strong>
                    </span>
                <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
            </div>

            <div class="social-auth-links text-center">
                    <button type="submit" class="btn btn-primary btn-block btn-social  btn-flat">
                        <?php echo e(__('Send Password Reset Link')); ?>

                    </button>
            </div>
        </form>
        <a href="<?php echo e(route('login')); ?>"><?php echo e(__('Back to login')); ?></a><br>

    </div>
    <!-- /.login-box-body -->
</div>
<!-- /.login-box -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/soccertipstar/soccertipstar/resources/views/auth/passwords/email.blade.php ENDPATH**/ ?>