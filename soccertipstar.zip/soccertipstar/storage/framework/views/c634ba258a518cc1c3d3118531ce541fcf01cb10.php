<?php $__env->startSection('content'); ?>
<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            User Profile
        </h1>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-3">
                <!-- Profile Image -->
                <div class="box box-primary">
                    <div class="box-body box-profile">
                        <img class="profile-user-img img-responsive img-circle"
                            src="/<?php echo e($user->profile->profileImage()); ?>" alt="User profile picture">
                        <h3 class="profile-username text-center"><?php echo e($user->first_name.' '.$user->last_name); ?> </h3>
                        <ul class="list-group list-group-unbordered">
                            <?php echo e($user->roles->count()==0?'You have no role':''); ?>

                            <?php $__currentLoopData = $user->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-group-item"><?php echo e($role->display_name); ?> (<?php echo e($role->description); ?>)</li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <ul class="list-group list-group-unbordered">
                            <li class="list-group-item">
                                <b>Total posts</b> <a class="pull-right"><?php echo e($user->posts->count()); ?></a>
                            </li>
                        </ul>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->

                <!-- About Me Box -->
                <div class="box box-primary">
                    <div class="box-header with-border">
                        <h3 class="box-title">About Me</h3>
                    </div>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <strong><i class="fa fa-file-text-o margin-r-5"></i> Bio</strong>
                        <p><?php echo e($user->profile->bio); ?></p>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
            <div class="col-md-9">
                <div class="nav-tabs-custom">
                    <ul class="nav nav-tabs">
                        <li class="active"><a href="#timeline" data-toggle="tab">Timeline</a></li>
                        <li><a href="#settings" data-toggle="tab">Settings</a></li>
                        <li><a href="#password" data-toggle="tab">Password</a></li>
                    </ul>
                    <div class="tab-content">
                        <div class="active tab-pane" id="timeline">

                        </div>
                        <!-- /.tab-pane -->

                        <div class="tab-pane" id="settings">
                            <form class="form-horizontal" action="/profile/<?php echo e($user->id); ?>" enctype="multipart/form-data"
                                method="post">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PATCH'); ?>
                                <!-- First name-->
                                <div class="form-group">
                                    <label for="first_name" class="col-sm-2 control-label">First name</label>

                                    <div class="col-sm-10">
                                        <input type="first_name" name="first_name"
                                            class="form-control <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                            id="first_name" placeholder="First name"
                                            value="<?php echo e(old('first_name') ?? $user->first_name); ?>">

                                        <?php if ($errors->has('first_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('first_name'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /First name-->

                                <!-- Last name-->
                                <div class="form-group">
                                    <label for="last_name" class="col-sm-2 control-label">Last name</label>

                                    <div class="col-sm-10">
                                        <input type="last_name" name="last_name"
                                            class="form-control  <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                            id="last_name" placeholder="Last name"
                                            value="<?php echo e(old('last_name') ?? $user->last_name); ?>">

                                        <?php if ($errors->has('last_name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('last_name'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /Last name -->

                                <!-- Email-->
                                <div class="form-group">
                                    <label for="email" class="col-sm-2 control-label">Email</label>

                                    <div class="col-sm-10">
                                        <input type="email" name="email"
                                            class="form-control <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" id="email"
                                            placeholder="Email" value="<?php echo e(old('email') ?? $user->email); ?>">

                                        <?php if ($errors->has('email')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('email'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /Email-->

                                <!-- /Mobile no-->
                                <div class="form-group">
                                    <label for="mobile_no" class="col-sm-2 control-label">Mobile no.</label>

                                    <div class="col-sm-10">
                                        <input type="text" name="mobile_no" class="form-control" id="mobile_no"
                                            placeholder="Mobile no."
                                            value="<?php echo e(old('mobile_no') ?? $user->profile->mobile_no); ?>">

                                        <?php if ($errors->has('mobile_no')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('mobile_no'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /mobile no-->

                                <!-- sex-->
                                <div class="form-group">
                                    <label for="sex" class="col-sm-2 control-label">Sex</label>
                                    <div class="col-sm-10">
                                        <select name="sex" id="sex" class="form-control select2" style="width: 100%;">
                                            <option value=""></option>
                                            <option <?php if($user->profile->sex === 'M'): ?> selected="selected" <?php endif; ?>
                                                value="M">Male</option>
                                            <option <?php if($user->profile->sex === 'F'): ?> selected="selected" <?php endif; ?>
                                                value="F">Female</option>
                                        </select>
                                    </div>
                                </div>
                                <!-- sex-->
                                <!-- twitter url -->
                                <div class="form-group">
                                    <label for="twitter_url" class="col-sm-2 control-label">Twitter url</label>

                                    <div class="col-sm-10">
                                        <input type="text" name="twitter_url"
                                            class="form-control <?php if ($errors->has('twitter_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('twitter_url'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                            id="twitter_url" placeholder="Twitter url"
                                            value="<?php echo e(old('twitter_url') ?? $user->profile->twitter_url); ?>">

                                        <?php if ($errors->has('twitter_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('twitter_url'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /twitter url -->

                                <!-- facebook url -->
                                <div class="form-group">
                                    <label for="facebook_url" class="col-sm-2 control-label">Facebook url</label>

                                    <div class="col-sm-10">
                                        <input type="text" name="facebook_url"
                                            class="form-control <?php if ($errors->has('facebook_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('facebook_url'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                            id="facebook_url" placeholder="Facebook url"
                                            value="<?php echo e(old('facebook_url') ?? $user->profile->facebook_url); ?>">

                                        <?php if ($errors->has('facebook_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('facebook_url'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /facebook url -->

                                <!-- insta url -->
                                <div class="form-group">
                                    <label for="instagram_url" class="col-sm-2 control-label">instagram url</label>

                                    <div class="col-sm-10">
                                        <input type="text" name="instagram_url"
                                            class="form-control <?php if ($errors->has('instagram_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('instagram_url'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>"
                                            id="instagram_url" placeholder="Instagram url"
                                            value="<?php echo e(old('instagram_url') ?? $user->profile->instagram_url); ?>">

                                        <?php if ($errors->has('instagram_url')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('instagram_url'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /insta url -->

                                <!-- bio -->
                                <div class="form-group">
                                    <label for="bio" class="col-sm-2 control-label">Bio</label>

                                    <div class="col-sm-10">
                                        <textarea class="form-control <?php if ($errors->has('bio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bio'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="bio"
                                            id="bio" placeholder=""><?php echo e(old('bio') ?? $user->profile->bio); ?></textarea>

                                        <?php if ($errors->has('bio')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('bio'); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                        <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                    </div>
                                </div>
                                <!-- /bio -->

                                <div class="form-group">
                                    <label for="image" class="col-sm-2 control-label">Profile image</label>

                                    <div class="col-sm-10">
                                        <input type="file" name="image" id="image">
                                    </div>
                                </div>

                                <div class="form-group">
                                    <div class="col-sm-offset-2 col-sm-10">
                                        <button type="submit" class="btn btn-primary btn-flat">Submit</button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <!-- /.tab-pane -->

                        <div class="tab-pane" id="password">
                            <div class="container">
                                <div class="row justify-content-center">
                                    <div class="col-md-8">
                                        <div class="card">
                                            <div class="card-body">
                                                <?php if(session('error')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e(session('error')); ?>

                                                </div>
                                                <?php endif; ?>
                                                <?php if(session('success')): ?>
                                                <div class="alert alert-success">
                                                    <?php echo e(session('success')); ?>

                                                </div>
                                                <?php endif; ?>
                                                <form class="form-horizontal" method="POST" action="/changePassword">
                                                    <?php echo csrf_field(); ?>
                                                    <div
                                                        class="form-group<?php echo e($errors->has('current-password') ? ' has-error' : ''); ?>">
                                                        <label for="new-password" class="col-md-4 control-label">Current
                                                            Password</label>

                                                        <div class="col-md-6">
                                                            <input id="current-password" type="password"
                                                                class="form-control" name="current-password" required>

                                                            <?php if($errors->has('current-password')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('current-password')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div
                                                        class="form-group<?php echo e($errors->has('new-password') ? ' has-error' : ''); ?>">
                                                        <label for="new-password" class="col-md-4 control-label">New
                                                            Password</label>

                                                        <div class="col-md-6">
                                                            <input id="new-password" type="password"
                                                                class="form-control" name="new-password" required>

                                                            <?php if($errors->has('new-password')): ?>
                                                            <span class="help-block">
                                                                <strong><?php echo e($errors->first('new-password')); ?></strong>
                                                            </span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label for="new-password-confirm"
                                                            class="col-md-4 control-label">Confirm New Password</label>

                                                        <div class="col-md-6">
                                                            <input id="new-password-confirm" type="password"
                                                                class="form-control" name="new-password_confirmation"
                                                                required>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <div class="col-md-6 col-md-offset-4">
                                                            <button type="submit" class="btn btn-primary btn-flat">
                                                                Change Password
                                                            </button>
                                                        </div>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.tab-pane -->
                    </div>
                    <!-- /.tab-content -->
                </div>
                <!-- /.nav-tabs-custom -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<!-- /.content-wrapper -->


<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 2.4.0
    </div>
    <strong>Copyright &copy; 2014-2016 <a href="https://adminlte.io">Almsaeed Studio</a>.</strong> All rights
    reserved.
</footer>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/soccertipstar/soccertipstar/resources/views/home/profile/show.blade.php ENDPATH**/ ?>