<?php $__env->startSection('content'); ?>
<div class="site-main-container">
    <!-- Start top-post Area -->
    <section class="top-post-area pt-10">
        <div class="container no-padding">
            <div class="row small-gutters">

                <div class="col-lg-8 top-post-left">
                    <div class="feature-image-thumb relative">
                        <div class="overlay overlay-bg"></div>
                        <?php
                            $recent_post_0_images = explode(',',$recent_posts[0]->image);
                        ?>
                        <img class="img-fluid" src="/storage/<?php echo e($recent_post_0_images[0]); ?>" alt="">
                    </div>
                    <div class="top-post-details">
                        <a href="/post/<?php echo e($recent_posts[0]->slug); ?>">
                            <h3><?php echo e($recent_posts[0]->title); ?></h3>
                        </a>
                        <ul class="meta">
                            <li><a href="#"><span class="lnr lnr-user"></span>
                                    <?php echo e($recent_posts[0]->user->first_name.' '.$recent_posts[0]->user->last_name); ?>

                                </a></li>
                            <li><a href="#"><span class="lnr lnr-calendar-full"></span>
                                    <?php echo e($recent_posts[0]->published_at); ?>

                                </a></li>
                        </ul>
                    </div>
                </div>

                <div class="col-lg-4 top-post-right">
                    <div class="single-top-post">
                        <div class="feature-image-thumb relative">
                            <div class="overlay overlay-bg"></div>
                            <?php
                                $recent_post_1_images = explode(',',$recent_posts[1]->image);
                            ?>
                            <img class="img-fluid" src="/storage/<?php echo e($recent_post_1_images[1]); ?>" alt="">
                        </div>
                        <div class="top-post-details">
                            <a href="/post/<?php echo e($recent_posts[1]->slug); ?>">
                                <h4><?php echo e($recent_posts[1]->title); ?></h4>
                            </a>
                            <ul class="meta">
                                <li><a href="#"><span class="lnr lnr-user"></span>
                                        <?php echo e($recent_posts[1]->user->first_name.' '.$recent_posts[1]->user->last_name); ?>

                                    </a></li>
                                <li><a href="#"><span class="lnr lnr-calendar-full"></span>
                                        <?php echo e($recent_posts[1]->published_at); ?>

                                    </a></li>
                            </ul>
                        </div>
                    </div>
                    <div class="single-top-post mt-10">
                        <div class="feature-image-thumb relative">
                            <div class="overlay overlay-bg"></div>
                            <?php
                                $recent_post_2_images = explode(',',$recent_posts[2]->image);
                            ?>
                            <img class="img-fluid" src="/storage/<?php echo e($recent_post_2_images[1]); ?>" alt="">
                        </div>
                        <div class="top-post-details">
                            <a href="/post/<?php echo e($recent_posts[2]->slug); ?>">
                                <h4><?php echo e($recent_posts[2]->title); ?></h4>
                            </a>
                            <ul class="meta">
                                <li><a href="#"><span class="lnr lnr-user"></span>
                                        <?php echo e($recent_posts[2]->user->first_name.' '.$recent_posts[2]->user->last_name); ?>

                                    </a></li>
                                <li><a href="#"><span class="lnr lnr-calendar-full"></span>
                                        <?php echo e($recent_posts[2]->published_at); ?>

                                    </a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End top-post Area -->
    <!-- Start latest-post Area -->
    <section class="latest-post-area pb-120">
        <div class="container no-padding">
            <div class="row">
                <div class="col-lg-8 post-list">
                    <!-- Start latest-post Area -->
                    <div class="latest-post-wrap">
                        <h4 class="cat-title">Latest News</h4>
                        <?php if(count($posts) > 0): ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="single-latest-post row align-items-center">
                            <div class="col-lg-5 post-left">
                                <div class="feature-img relative">
                                    <div class="overlay overlay-bg"></div>
                                    <?php
                                        $post_images = explode(',',$post->image);
                                    ?>
                                    <img class="img-fluid" src="/storage/<?php echo e($post_images[2]); ?>" alt="">
                                </div>
                            </div>
                            <div class="col-lg-7 post-right">
                                <a href="/post/<?php echo e($post->slug); ?>">
                                    <h4><?php echo e($post->title); ?></h4>
                                </a>
                                <ul class="meta">
                                    <li><a href="#"><span class="lnr lnr-user"></span>
                                            <?php echo e($post->user->first_name.' '.$post->user->last_name); ?>

                                        </a></li>
                                    <li><a href="#"><span class="lnr lnr-calendar-full"></span>
                                            <?php echo e($post->published_at); ?></a>
                                    </li>
                                </ul>
                                <p class="excert"><?php echo $post->excerpt; ?></p>
                            </div>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div style="margin-top: 10px;">
                            <?php echo e($posts->links()); ?>

                        </div>
                        <?php endif; ?>
                    </div>
                    <!-- End latest-post Area -->

                    <!-- Start banner-ads Area -->
                    <div class="col-lg-12 ad-widget-wrap mt-30 mb-30">
                        <img class="img-fluid" src="storage/img/banner-ad.jpg" alt="">
                    </div>
                    <!-- End banner-ads Area -->
                    
                </div>
                <div class="col-lg-4">
                    <div class="sidebars-area">
                        <div class="single-sidebar-widget editors-pick-widget">
                            <h6 class="title">Editor’s Pick</h6>
                            <div class="editors-pick-post">
                                <?php if(count($featured_posts)>0): ?>  
                                <div class="feature-img-wrap relative">
                                    <div class="feature-img relative">
                                        <div class="overlay overlay-bg"></div>
                                        <?php
                                            $featured_post_0_images = explode(',',$featured_posts[0]->image);
                                        ?>
                                        <img class="img-fluid" src="/storage/<?php echo e($featured_post_0_images[3]); ?>" alt="">
                                    </div>
                                </div>
                                <div class="details">
                                    <a href="/post/<?php echo e($featured_posts[0]->slug); ?>">
                                        <h4 class="mt-20"><?php echo e($featured_posts[0]->title); ?></h4>
                                    </a>
                                    <ul class="meta">
                                        <li><a href="#"><span class="lnr lnr-user"></span>
                                                <?php echo e($featured_posts[0]->user->first_name.' '.$featured_posts[0]->user->last_name); ?>

                                            </a></li>
                                        <li><a href="#"><span class="lnr lnr-calendar-full"></span>
                                                <?php echo e($featured_posts[0]->published_at); ?>

                                            </a></li>
                                    </ul>
                                    <p class="excert">
                                        <?php echo $featured_posts[0]->excerpt; ?>

                                    </p>
                                </div>
                                <div class="post-lists">
                                    <?php if(count($featured_posts)>1): ?>  
                                        <?php $__currentLoopData = $featured_posts->slice(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $featured_post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php
                                                $featured_posts_images = explode(',',$featured_post->image);
                                            ?>
                                        <div class="single-post d-flex flex-row">
                                            <div class="thumb">
                                                <img src="/storage/<?php echo e($featured_posts_images[4]); ?>" alt="">
                                            </div>
                                            <div class="detail">
                                                <a href="/post/<?php echo e($featured_post->slug); ?>">
                                                    <h6><?php echo e($featured_post->title); ?></h6>
                                                </a>
                                                <ul class="meta">
                                                    <li><a href="#"><span
                                                        class="lnr lnr-calendar-full"></span><?php echo e($featured_post->published_at); ?></a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        <div class="single-sidebar-widget ads-widget">
                            <img class="img-fluid" src="/storage/img/sidebar-ads.jpg" alt="">
                        </div>

                        <div class="single-sidebar-widget newsletter-widget">
                            <h6 class="title">Newsletter</h6>
                            <div class="form-group d-flex flex-row">
                                <div class="col-autos">
                                    <div class="input-group">
                                        <input class="form-control" placeholder="Email Address"
                                            onfocus="this.placeholder = ''" onblur="this.placeholder = 'Email Address'"
                                            type="text">
                                    </div>
                                </div>
                                <a href="#" class="bbtns">Subcribe</a>
                            </div>
                            <p>
                                You can unsubscribe us at any time to receive the latest news and other goodies as they become available.
                                We promise not to spam you.
                            </p>
                        </div>
                        <div class="single-sidebar-widget most-popular-widget">
                            <h6 class="title">Most Popular</h6>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End latest-post Area -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/soccertipstar/soccertipstar/resources/views/blog/index.blade.php ENDPATH**/ ?>